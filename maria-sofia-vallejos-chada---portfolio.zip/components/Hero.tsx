import React from 'react';
import { PROFILE } from '../constants';

const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-slate-900 text-white">
      {/* Abstract Background Shapes */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-orange-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob"></div>
        <div className="absolute top-0 -right-4 w-72 h-72 bg-slate-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000"></div>
        <div className="absolute -bottom-8 left-20 w-72 h-72 bg-orange-800 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-4000"></div>
      </div>

      <div className="container mx-auto px-6 relative z-10 flex flex-col md:flex-row items-center gap-12">
        
        {/* Text Content */}
        <div className="flex-1 text-center md:text-left">
          <div className="inline-block px-3 py-1 mb-4 border border-orange-500 rounded-full text-orange-400 text-sm tracking-widest uppercase font-semibold">
            Legal & Compliance
          </div>
          <h1 className="text-5xl md:text-7xl font-bold mb-6 tracking-tight leading-tight">
            Maria Sofia <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-slate-200">
              Vallejos Chada
            </span>
          </h1>
          <p className="text-slate-300 text-lg md:text-xl mb-8 max-w-2xl leading-relaxed">
            {PROFILE.role}. Especialista en regulación de activos digitales, tokenización y cumplimiento normativo global.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
            <a 
              href="#contact" 
              className="px-8 py-4 bg-orange-600 hover:bg-orange-700 text-white font-semibold rounded-lg transition-all shadow-[0_0_20px_rgba(234,88,12,0.3)] hover:shadow-[0_0_30px_rgba(234,88,12,0.5)]"
            >
              Contactar
            </a>
            <button 
              onClick={() => document.getElementById('chatbot-trigger')?.click()}
              className="px-8 py-4 bg-transparent border border-slate-600 hover:border-orange-500 text-slate-300 hover:text-white font-semibold rounded-lg transition-all"
            >
              Hablar con mi AI
            </button>
          </div>
        </div>

        {/* Image/Avatar */}
        <div className="relative w-64 h-64 md:w-96 md:h-96 flex-shrink-0">
          <div className="absolute inset-0 border-2 border-orange-500/30 rounded-full transform rotate-6 scale-105"></div>
          <div className="absolute inset-0 border-2 border-slate-500/30 rounded-full transform -rotate-6 scale-105"></div>
          <img 
            src="https://picsum.photos/400/400" 
            alt="Maria Sofia Vallejos Chada" 
            className="w-full h-full object-cover rounded-full border-4 border-slate-800 shadow-2xl grayscale hover:grayscale-0 transition-all duration-700"
          />
        </div>
      </div>
      
      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce text-slate-500">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
      </div>
    </section>
  );
};

export default Hero;