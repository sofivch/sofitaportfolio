import React from 'react';
import { EXPERIENCE } from '../constants';

const Experience: React.FC = () => {
  return (
    <section className="py-20 bg-white" id="experience">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-slate-800 mb-16 text-center">
          Experiencia <span className="text-orange-600">Profesional</span>
        </h2>

        <div className="relative max-w-4xl mx-auto">
          {/* Vertical Line */}
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-slate-200 transform -translate-x-1/2"></div>

          <div className="space-y-12">
            {EXPERIENCE.map((job, index) => (
              <div key={job.id} className={`relative flex flex-col md:flex-row gap-8 ${index % 2 === 0 ? 'md:flex-row-reverse' : ''}`}>
                
                {/* Timeline Dot */}
                <div className="absolute left-4 md:left-1/2 w-4 h-4 bg-orange-500 rounded-full border-4 border-white shadow transform -translate-x-1/2 mt-6 z-10"></div>

                {/* Content Card */}
                <div className="ml-12 md:ml-0 md:w-1/2 px-4">
                  <div className={`p-6 bg-slate-50 rounded-xl border border-slate-100 hover:border-orange-200 transition-all hover:shadow-lg ${index % 2 === 0 ? 'md:text-left' : 'md:text-right'}`}>
                    <span className="inline-block px-3 py-1 bg-slate-200 text-slate-600 text-xs font-bold rounded-full mb-3">
                      {job.period}
                    </span>
                    <h3 className="text-xl font-bold text-slate-900">{job.role}</h3>
                    <h4 className="text-lg text-orange-600 font-medium mb-4">{job.company}</h4>
                    <ul className={`space-y-2 text-slate-600 text-sm ${index % 2 === 0 ? 'md:items-start' : 'md:items-end flex flex-col'}`}>
                      {job.description.map((item, i) => (
                        <li key={i} className="flex gap-2">
                          <span className="text-orange-400 mt-1">•</span>
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                
                {/* Empty Spacer for alternating layout */}
                <div className="hidden md:block md:w-1/2"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Experience;