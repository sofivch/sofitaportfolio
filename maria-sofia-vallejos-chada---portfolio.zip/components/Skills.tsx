import React from 'react';
import { SKILLS, EDUCATION } from '../constants';

const SkillsAndEducation: React.FC = () => {
  return (
    <section className="py-20 bg-slate-50" id="skills">
      <div className="container mx-auto px-6">
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          
          {/* Skills Column */}
          <div>
            <h2 className="text-3xl font-bold text-slate-800 mb-8 border-l-4 border-orange-500 pl-4">
              Habilidades Clave
            </h2>
            <div className="grid gap-6">
              {SKILLS.map((skillGroup, idx) => (
                <div key={idx} className="bg-white p-6 rounded-lg shadow-sm border border-slate-100">
                  <h3 className="text-lg font-bold text-slate-700 mb-4">{skillGroup.category}</h3>
                  <div className="flex flex-wrap gap-2">
                    {skillGroup.items.map((item, i) => (
                      <span key={i} className="px-3 py-1 bg-slate-100 text-slate-700 rounded text-sm hover:bg-orange-50 hover:text-orange-700 transition-colors">
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Education Column */}
          <div>
            <h2 className="text-3xl font-bold text-slate-800 mb-8 border-l-4 border-orange-500 pl-4">
              Formación Académica
            </h2>
            <div className="space-y-4">
              {EDUCATION.map((edu) => (
                <div key={edu.id} className="group flex items-start p-4 bg-white rounded-lg border border-slate-100 hover:border-orange-300 transition-all">
                  <div className="flex-shrink-0 w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center text-orange-500 group-hover:bg-orange-500 group-hover:text-white transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14l9-5-9-5-9 5 9 5z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z" />
                    </svg>
                  </div>
                  <div className="ml-4">
                    <h3 className="font-bold text-slate-800">{edu.degree}</h3>
                    <p className="text-slate-500 text-sm">{edu.institution}</p>
                    <p className="text-orange-500 text-xs mt-1 font-mono">{edu.period}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default SkillsAndEducation;