import { ExperienceItem, EducationItem, Skill } from './types';

export const PROFILE = {
  name: "Maria Sofia Vallejos Chada",
  role: "Head of Legal and Compliance",
  location: "Ciudad Autónoma de Buenos Aires, Argentina",
  email: "sofivallejoschada@gmail.com",
  phone: "+5492664869711",
  linkedin: "https://www.linkedin.com/in/maria-sofia-vallejos/",
  summary: "Abogada con más de 6 años de experiencia en cumplimiento normativo, investigaciones forenses y regulación de activos digitales. Especialista en securities, marcos AML/KYC/KYB y licencias VASP. Experta en diseño de arquitecturas legales para tokenización (ERC-3643, ERC-20, RWA, stablecoins) y en mitigación de riesgos operativos dentro de ecosistemas blockchain globales."
};

export const EXPERIENCE: ExperienceItem[] = [
  {
    id: "1",
    role: "Head of Legal & Compliance",
    company: "BoulderTech",
    period: "10/2024 - Actualidad",
    description: [
      "Lidero la estrategia legal y regulatoria global para la tokenización de RWA (ERC-3643 y ERC-20) en Bermudas, El Salvador y Argentina.",
      "Gestiono la licencia DABA y el programa de cumplimiento continuo.",
      "Superviso la licencia VASP en El Salvador (matriz de riesgos, manuales AML/CFT, ciberseguridad).",
      "Evalúo requisitos PSAV y la RG 1060/2024 (CNV) para documentación de oferta pública y listados en Argentina.",
      "Negocio listados y programas de liquidez con CEX y DEX internacionales (MiCA, Reg S, Rule 144A)."
    ]
  },
  {
    id: "2",
    role: "Fundadora y Consultora Legal/Compliance Principal",
    company: "SVP Consulting",
    period: "08/2024 - Actualidad",
    description: [
      "Diseño marcos regulatorios integrales para proyectos Web3 (gaming, real estate, agricultura, fintech).",
      "Elaboro opiniones legales sobre stablecoins, NFTs y tokens valores.",
      "Defino estructuras corporativas (SPVs, Series LLC, SACs, DAOs) y estrategias fiscales transfronterizas.",
      "Coordino con reguladores, estudios jurídicos extranjeros y auditores de smart contracts."
    ]
  },
  {
    id: "3",
    role: "Asesora de Compliance Freelance",
    company: "Compliance Pymes",
    period: "08/2024 - Actualidad",
    description: [
      "Asesoro a PyMEs en la implementación de programas de compliance alineados con la UIF Argentina.",
      "Elaboro ROS y procedimientos internos de prevención AML/CFT.",
      "Redacto manuales AML/CFT y matrices de riesgo sectoriales."
    ]
  },
  {
    id: "4",
    role: "ADV Senior Associate 2 (Forensic & Compliance)",
    company: "PwC Argentina",
    period: "11/2023 - 08/2024",
    description: [
      "Realicé investigaciones por fraude y prevención AML/CFT; elaboré reportes para UIF/BCRA.",
      "Diseñé matrices de riesgo y procedimientos digitales AML/KYC para instituciones financieras."
    ]
  },
  {
    id: "5",
    role: "Estratega de Compliance y Regulación",
    company: "Wootic (Tokenize-it)",
    period: "06/2022 - 11/2023",
    description: [
      "Lideré la estrategia regulatoria para la tokenización de RWA.",
      "Implementé procesos de onboarding KYC/KYB y controles KYT.",
      "Coordiné la documentación legal (SAFE, SAFT)."
    ]
  }
];

export const EDUCATION: EducationItem[] = [
  { id: "1", degree: "MBA en Compliance, Fraude y Prevención de Lavado de Activos", institution: "EALDE / UCAM (España)", period: "2023 - 2024" },
  { id: "2", degree: "Curso Crypto Compliance", institution: "Fundación CRIMINT", period: "2024" },
  { id: "3", degree: "Certificación Internacional Ética & Compliance", institution: "UCEMA", period: "2023" },
  { id: "4", degree: "Posgrado en Derecho Empresarial", institution: "Universidad Católica de Córdoba", period: "2021" },
  { id: "5", degree: "Título de Abogada", institution: "Universidad Nacional de Córdoba", period: "2014 - 2018" }
];

export const SKILLS: Skill[] = [
  {
    category: "Legal Tech & Crypto",
    items: ["Tokenización (ERC-20/3643)", "Licencias DABA/VASP/PSAV", "Regulación MiCA/CNV", "Smart Contracts Audit Coord", "Web3 Frameworks"]
  },
  {
    category: "Compliance & Riesgo",
    items: ["AML / CFT / KYB / KYC", "Investigaciones Forenses", "Matrices de Riesgo", "Due Diligence", "Reportes Regulatorios (ROS)"]
  },
  {
    category: "Idiomas",
    items: ["Español (Nativo)", "Inglés (Avanzado C1)", "Italiano (Básico)", "Francés (Básico)"]
  }
];

// System prompt for the Gemini Chatbot
export const SYSTEM_PROMPT = `
Eres un asistente virtual que representa a Maria Sofia Vallejos Chada. Tu objetivo es responder preguntas sobre su experiencia profesional, habilidades y educación basándote ESTRICTAMENTE en la siguiente información.

Perfil: ${PROFILE.summary}
Experiencia: ${JSON.stringify(EXPERIENCE)}
Educación: ${JSON.stringify(EDUCATION)}
Habilidades: ${JSON.stringify(SKILLS)}

Instrucciones de comportamiento:
1. Responde siempre en primera persona ("Yo tengo experiencia en...", "Mi enfoque es...") o tercera persona profesional ("Sofia es experta en..."), pero mantén un tono profesional, amable y experto.
2. Si te preguntan sobre contacto, ofrece su email: ${PROFILE.email}.
3. Se conciso pero informativo.
4. Si te preguntan algo que no está en la información provista, di cortésmente que no tienes esa información específica pero resalta una habilidad relacionada.
5. El tono debe ser sofisticado, legal-tech, innovador.
`;
