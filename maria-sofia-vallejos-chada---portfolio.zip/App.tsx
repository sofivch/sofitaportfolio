import React from 'react';
import Hero from './components/Hero';
import Experience from './components/Experience';
import SkillsAndEducation from './components/Skills';
import ChatBot from './components/ChatBot';
import { PROFILE } from './constants';

const App: React.FC = () => {
  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-slate-900/90 backdrop-blur-md z-40 border-b border-slate-800">
        <div className="container mx-auto px-6 py-4 flex justify-between items-center">
          <div className="text-xl font-bold text-white tracking-tighter">
            MS<span className="text-orange-500">VC</span>
          </div>
          <div className="hidden md:flex gap-8 text-sm font-medium text-slate-300">
            <a href="#" className="hover:text-orange-500 transition-colors">Inicio</a>
            <a href="#experience" className="hover:text-orange-500 transition-colors">Experiencia</a>
            <a href="#skills" className="hover:text-orange-500 transition-colors">Habilidades</a>
          </div>
          <a 
            href={PROFILE.linkedin} 
            target="_blank" 
            rel="noreferrer"
            className="text-slate-300 hover:text-white transition-colors"
          >
             <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.239-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
          </a>
        </div>
      </nav>

      {/* Main Content */}
      <main>
        <Hero />
        <Experience />
        <SkillsAndEducation />
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-12" id="contact">
        <div className="container mx-auto px-6 text-center">
          <h3 className="text-2xl font-bold text-white mb-6">Contáctame</h3>
          <p className="mb-8 max-w-lg mx-auto">
            ¿Buscas asesoría en regulación cripto, cumplimiento o tokenización?
            Escríbeme para discutir cómo puedo ayudar en tu proyecto.
          </p>
          <div className="flex justify-center gap-6 mb-8">
            <a href={`mailto:${PROFILE.email}`} className="px-6 py-3 border border-slate-600 rounded hover:bg-slate-800 hover:border-orange-500 hover:text-orange-500 transition-all">
              Enviar Email
            </a>
            <a href={PROFILE.linkedin} target="_blank" rel="noreferrer" className="px-6 py-3 bg-orange-600 text-white rounded hover:bg-orange-700 transition-all">
              LinkedIn
            </a>
          </div>
          <div className="text-xs text-slate-600">
            &copy; {new Date().getFullYear()} Maria Sofia Vallejos Chada. Todos los derechos reservados.
          </div>
        </div>
      </footer>

      {/* Chatbot Integration */}
      <ChatBot />
    </div>
  );
};

export default App;