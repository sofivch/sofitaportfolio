import { GoogleGenAI } from "@google/genai";
import { SYSTEM_PROMPT } from '../constants';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const sendMessageToGemini = async (
  message: string,
  history: { role: string; text: string }[]
): Promise<string> => {
  try {
    // Convert generic history format to Gemini format if needed, 
    // but for simple single-turn or context injection, we can use generateContent with system instruction.
    // For better chat context, we construct a conversation string or use the chat API.
    // Given the constraints and library version guidelines, let's use the chat model.
    
    const chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: SYSTEM_PROMPT,
        temperature: 0.7,
      },
      history: history.map(h => ({
        role: h.role,
        parts: [{ text: h.text }]
      }))
    });

    const result = await chat.sendMessage({ message: message });
    return result.text || "Disculpa, no pude procesar eso correctamente.";
    
  } catch (error) {
    console.error("Error communicating with Gemini:", error);
    return "Lo siento, hubo un error al conectar con mi cerebro digital. Por favor intenta de nuevo.";
  }
};